package com.fouridiots.capstone.repository;

import com.fouridiots.capstone.domain.PayMenu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PayMenuRepository extends JpaRepository<PayMenu, Long> {

    // payId로 결제된 메뉴들을 조회
    List<PayMenu> findByPayPayId(Long payId);

    // cartId로 결제된 메뉴들을 조회 (PayRepository의 결제 정보를 사용)
    List<PayMenu> findByPayCartCartId(Long cartId);
}
