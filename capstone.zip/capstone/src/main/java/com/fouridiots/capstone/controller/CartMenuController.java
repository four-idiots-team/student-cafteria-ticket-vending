package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.CartMenu;
import com.fouridiots.capstone.service.CartMenuService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/security-login/cart")
@RequiredArgsConstructor
public class CartMenuController {

    private final CartMenuService cartMenuService;

    // 장바구니 항목 조회
    @GetMapping("/items")
    public List<CartMenu> getCartItems(@RequestParam String loginId) {
        return cartMenuService.getCartMenus(loginId);
    }
    // 메뉴 추가
    @PostMapping("/add")
    public ResponseEntity<String> addMenuToCart(@RequestParam String loginId,
                                                @RequestParam Long menuId,
                                                @RequestParam int count) {
        try {
            cartMenuService.addMenuToCart(loginId, menuId, count);  // 메뉴 추가 서비스 호출
            return ResponseEntity.ok("메뉴가 장바구니에 추가되었습니다.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("메뉴 추가 중 오류가 발생했습니다.");
        }
    }

    // 수량 변경 (PUT /spring-security/cart/update/{menuId}?count=3&loginId=user1)
    @PutMapping("/update/{menuId}")
    public ResponseEntity<String> updateCartMenuCount(@PathVariable Long menuId,
                                                      @RequestParam String loginId,
                                                      @RequestParam int count) {
        try {
            cartMenuService.updateCartMenuCount(loginId, menuId, count);
            return ResponseEntity.ok("장바구니 수량이 업데이트되었습니다.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("수량 업데이트 중 오류가 발생했습니다.");
        }
    }


    // 메뉴 삭제 (DELETE /spring-security/cart/{cartMenuId})
    @DeleteMapping("/{cartMenuId}")
    public ResponseEntity<String> deleteCartMenu(@PathVariable Long cartMenuId,
                                                 @RequestParam String loginId) {
        try {
            cartMenuService.removeCartMenu(loginId, cartMenuId);
            return ResponseEntity.ok("메뉴가 장바구니에서 삭제되었습니다.");
        } catch (Exception e) {
            return ResponseEntity.status(400).body("메뉴 삭제 중 오류가 발생했습니다.");
        }
    }
}
