package com.fouridiots.capstone.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
public class PayInfoResponse {
    private String loginId;
    private String studentId;
    private String userName;
    private Long cartId;  // cartId
    private List<MenuInfo> menuList;
    private int totalPrice;
    private String reservationTime;

    @Data
    @AllArgsConstructor
    public static class MenuInfo {
        private Long menuId;
        private String menuName;
        private int price;
        private int quantity;
    }
}
