package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

/*
User
  |
  | (1:1)
  ↓
Cart
  |
  | (1:N)
  ↓
CartMenu (중간 테이블)
  |
  | (N:1)
  ↓
Menu
- 하나의 유저는 하나의 장바구니

- 장바구니에는 여러 메뉴가 담기고

- 같은 메뉴가 여러 장바구니에도 들어갈 수 있음


*/
//장바구니에 담긴 메뉴
@Entity
@NoArgsConstructor
@Getter
@Table(name="cart_menu",
        //하이버네이트가 중복을 방지하는 유니크 키를 자동 생성 -> DB에서 Column의 중복을 막기 위함
        uniqueConstraints = {@UniqueConstraint(columnNames = {"cart_id",
                                                              "menu_id"})
                            }
)
public class CartMenu {
/*   
    IDENTITY	DB의 AUTO_INCREMENT 기능을 그대로 사용함. MySQL에 최적화.
    AUTO (기본값)	Hibernate가 DB 방언(dialect)에 따라 자동 선택
    경우에 따라, AUTO_INCREMENT를 지원하지 않는 경우에는 SEQUENCE 방식으로 id 값을 증가 시킴
    */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cart_menu_id") // 장바구니에 담긴 menu들을 가져오기 위한 PK
    private Long cartMenuId;

    // N:N 관계 == 장바구니에는 여러개의 메뉴가 담김 -> 이 관계 해소를 위해 Cart -> Menu <- CarMenu로 만들기 위함
    @ManyToOne(fetch= FetchType.LAZY)
    @JoinColumn(name="cart_id", nullable = false) // 장바구니id
    private Cart cart;
    
    // 여러개의 메뉴를 가질 수 있음
    @ManyToOne(fetch= FetchType.LAZY)
    @JoinColumn(name="menu_id", nullable=false) // Menu 테이블의 PK -> Forein Key
    private Menu menu;

/*    @Column(name="quantity", nullable = false) // 수량
    private int quantity;*/

    // 장바구니 품목의 최소 수량 = 1 지정 @Min
    @Min(value = 1, message = "상품을 담아주세요")
    @Column(nullable = false)
    private int count;

    public CartMenu(Cart cart, Menu menu, int count) {
        this.cart = cart;
        this.menu = menu;
        this.count = count;
    }
    // CartMenu.java
    public void changeCount(int newCount) {

        this.count = newCount;
    }
    public void addCount(int additional) {

        this.count += additional;
    }
}
