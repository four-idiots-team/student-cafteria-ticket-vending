package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pay")
public class Pay {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pay_id", nullable = false)
    private Long payId; // 결제 고유 ID

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cart_id", nullable = false)
    private Cart cart; // 결제에 관련된 장바구니 (1:1 관계)

    @Column(name = "total_price", nullable = false)
    private int totalPrice; // 총 결제 금액

    @Column(name = "pay_date", nullable = false)
    private LocalDateTime payDate; // 결제 일시

    @Column(name = "status", nullable = false)
    private String status; // 결제 상태 (예: "SUCCESS", "FAILURE")

    @Column(name = "success", nullable = false)
    private boolean success; // ← 여기 추가!
    // 생성자
    public Pay(Cart cart, int totalPrice, String status, boolean success) {
        this.cart = cart;
        this.totalPrice = totalPrice;
        this.status = status;
        this.success = success;
    }


    // 결제 일시 설정
    @PrePersist
    protected void onCreate() {
        this.payDate = LocalDateTime.now(); // 결제 일시는 현재 시간으로 설정
    }
}
