package com.fouridiots.capstone.domain;

import com.fouridiots.capstone.domain.Pay;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
public class PayMenu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payMenuId;

    @ManyToOne(fetch = FetchType.LAZY)  // ManyToOne 관계 설정
    @JoinColumn(name="menu_id")
    private Menu menu; // Menu 엔티티와의 관계

    @Column(nullable = false)
    private int count; // 수량

    @ManyToOne(fetch = FetchType.LAZY)  // Pay 엔티티와의 관계
    @JoinColumn(name = "pay_id")
    private Pay pay;
    // 생성자 추가: Pay, Menu, count 를 받아 초기화
    public PayMenu(Pay pay, Menu menu, int count) {
        this.pay = pay;
        this.menu = menu;
        this.count = count;
    }

}
