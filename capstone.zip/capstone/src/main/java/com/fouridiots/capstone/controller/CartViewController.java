package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.Category;
import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.service.CartService;
import com.fouridiots.capstone.service.CategoryService;
import com.fouridiots.capstone.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/security-login")
@RequiredArgsConstructor
public class CartViewController {
    private final UserService userService;
    private final CategoryService categoryService;
    private final CartService cartService; // CartService 주입

    // 장바구니 조회
    @GetMapping("/cart")
    public String viewCartMenu(Authentication auth, Model model) {
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("loginType", "security-login");
        model.addAttribute("pageName", "세명학식");

        if (auth != null && auth.isAuthenticated()) {
            String loginId = auth.getName(); // 로그인 아이디 가져옴
            User loginUser = userService.getLoginUserByLoginId(loginId);
            Cart cart = cartService.createCart(loginId);
            if (loginUser != null) {
                model.addAttribute("name", loginUser.getName());
                model.addAttribute("cartId", cart.getCartId());
                // 장바구니 초기화!
                cartService.clearCartForUserByUsername(loginId);
            }
        }

        return "cart";
    }
}
