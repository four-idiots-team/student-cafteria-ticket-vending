package com.fouridiots.capstone.config;

import com.fouridiots.capstone.domain.UserRole;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class SecurityConfig {
    // static resources 불러오기 -> filterchain 무시하기
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring()
                        .requestMatchers("/js/**")
                .requestMatchers("/img/**")
                .requestMatchers("/main.css");

    }

    // 시큐리티 필터 메서드
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{

        // http.authorizeHttpRequests( (auth) -> auth    : 각 url 별로 인가 설정
        // .requestMatchers() : 특정 URL에 대한 설정
                         // .permitAll() : 로그인 하지 않아도 모든 사용자가 접근 가능
                        // .authenticated() : 로그인만 한다면 모든 사용자가 접근 가능
                        //.hasRole() : 로그인 이후에 특정 role이 있어야 접근 가능
                       // .hasAnyRole() : hasRole과 같지만 여러개의 role 설정 가능
        // .anyRequest() : 위에서 처리하지 않은 나머지 경로에 대한 처리
        http.authorizeHttpRequests(
                (auth) -> auth
                        .requestMatchers("/").permitAll()
                        .requestMatchers("/security-login", "/security-login/login", "/security-login/join").permitAll()
                        .requestMatchers("/security-login/admin").hasRole(UserRole.ADMIN.name())
                        .requestMatchers("/security-login/info").hasAnyRole(UserRole.ADMIN.name(), UserRole.USER.name())
                        .anyRequest().authenticated()
                );

        //http.logout( (auth) -> auth    : 로그아웃 설정
        http.logout((auth) -> auth
                        .logoutUrl("/security-login/logout") //.logoutUrl() : 로그아웃이 발생하는 페이지 URL
                );
        // http.formLogin( (auth) -> auth    : 로그인 설정
        http.formLogin((auth) -> auth
                .loginPage("/security-login/login") // 로그인 페이지 URL
                .loginProcessingUrl("/security-login/loginProc")
                // 로그인 요청을 처리하는 URL -> 프론트단 (html)에서 넘어온 로그인 정보를 해당 경로로 넘기면 스프링 시큐리티가 받아서 자동으로 로그인 진행
                .failureUrl("/security-login/login") // 로그인 실패시
                .defaultSuccessUrl("/security-login") // 로그인 성공
                .usernameParameter("loginId")
                .passwordParameter("password")

                .permitAll()
        );
        
        http.csrf((auth) -> auth.disable());
        //http.csrf(AbstractHttpConfigurer::disable);

        return http.build();

    }


    //Password Bcrypt 암호화
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder(){

        return new BCryptPasswordEncoder();
    }

}

