package com.fouridiots.capstone.dto;


import com.fouridiots.capstone.domain.Menu;
import com.fouridiots.capstone.domain.User;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Builder;
import lombok.Getter;

@Getter
public class CartRequest {

    private Long cartId;

    private Long menuId;

    private Long id;

    private int quantity;

    @Builder
    public CartRequest(Long menuId, Long id) {
        this.menuId = menuId;
        this.id = id;
    }
}
