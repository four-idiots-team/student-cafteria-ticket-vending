package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@NoArgsConstructor
@Table(name="cart")
//사용자 별 장바구니 생성
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT를 반영 = 자동증가
    @Column(name="cart_id", nullable = false) // 장바구니PK
    private Long cartId;

    // 1:1 == User(사용자)는 장바구니를 하나만 가질 수 있음
    @OneToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="user_id", nullable=false) // User 테이블의 PK -> FK(Foreign Key)
    private User user;

    // 1:N == OneToMany	하나가 여러 개를 가짐 (한 장바구니 → 여러 상품)
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL)
    private List<CartMenu> cartMenus = new ArrayList<>();

    @Column(name = "created_at") // 장바구니 생성 시각
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @Setter
    @Column(name = "reservation_time")
    private LocalDateTime reservationTime;  // 예약 시간 추가

    @OneToOne(mappedBy = "cart")
    private Pay pay; // 카트에 해당하는 결제 정보
    public Cart(User user, LocalDateTime reservationTime) {
        this.user = user;
        this.createdAt = LocalDateTime.now(); // YYYY-MM-DD HH:mm 로컬 시각으로 설정
        this.reservationTime = reservationTime; // 직접 LocalDateTime을 받는다
    }

}

