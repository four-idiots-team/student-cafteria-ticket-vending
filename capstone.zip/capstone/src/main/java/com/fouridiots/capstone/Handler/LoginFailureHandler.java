package com.fouridiots.capstone.Handler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

import java.io.IOException;
import java.net.URLEncoder;

@Configuration
public class LoginFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception) throws IOException, ServletException {
        String loginId = request.getParameter("loginId"); // 사용자가 입력한 아이디
        String password = request.getParameter("password");

        StringBuilder errorMessageBuilder = new StringBuilder();

        /* BadCredentialsException
        자격 증명이 잘못되어 인증 요청이 거부된 경우 throw
        아이디나 비밀번호를 잘못 입력했을 때 발생한다 */
        if (exception instanceof BadCredentialsException) {
            errorMessageBuilder.append("아이디(로그인 전화번호, 로그인 전용 아이디) 또는 비밀번호가 잘못 되었습니다. 아이디와 비밀번호를 정확히 입력해 주세요.");
        }

        // 아이디와 비밀번호가 모두 비어 있을 때 처리
        if ((loginId == null || loginId.trim().isEmpty()) && (password == null || password.trim().isEmpty())) {
            errorMessageBuilder.append("아이디와 비밀번호를 입력해주세요.");
        }
        else {
            // 아이디가 비어 있을 경우
            if (loginId == null || loginId.trim().isEmpty()) {
                errorMessageBuilder.append("아이디를 입력해주세요. ");
            }
            // 비밀번호가 비어 있을 경우
            if (password == null || password.trim().isEmpty()) {
                errorMessageBuilder.append("비밀번호를 입력해주세요.");
            }
        }

        // 메시지가 하나도 추가되지 않으면 기본 에러 메시지
        if (errorMessageBuilder.length() == 0) {
            errorMessageBuilder.append("아이디(로그인 전화번호, 로그인 전용 아이디) 또는 비밀번호가 잘못 되었습니다. 아이디와 비밀번호를 정확히 입력해 주세요.");
        }

        // 최종 에러 메시지
        String errorMessage = errorMessageBuilder.toString();

        // 특정 인코딩 체계를 사용하여 문자열을 형식으로 변환
        errorMessage = URLEncoder.encode(errorMessage, "UTF-8");

        // URL에 error와 exception 파라미터를 포함하여 로그인 실패 페이지로 리디렉션
        setDefaultFailureUrl("/security-login/login?error=true&exception=" + errorMessage);

        super.onAuthenticationFailure(request, response, exception);
    }
}
