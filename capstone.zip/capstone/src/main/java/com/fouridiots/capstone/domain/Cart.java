/*
package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.Getter;

// Domain에서 setter를 사용하지 않는 이유는 객체의 정보 은닉X, 도메인 로직이 Distribute
@Entity
@Getter
@Table(name = "cart")
public class Cart {
    private Long cartId;
    private String menuName;
}
*/
