document.addEventListener("DOMContentLoaded", function () {
    // IMP는 포트원의 통합 결제 솔루션인 (IMPORT)아임포트
    var IMP = window.IMP;
    IMP.init('imp17338887'); // 실제 발급받은 IMP Key

    // 서버에서 결제 정보(PayInfoResponse) 가져오기
    function fetchPayInfo(loginId) {
        return fetch(`/security-login/payment/info?loginId=${loginId}`).then(response => response.json());
    }

    // 결제 성공 후 서버로 결제 데이터를 보내는 함수
    function paySuccess(rsp) {
        const loginId = rsp.custom_data.loginId;  // 커스텀 데이터에서 꺼내기
        const paymentData = {
            imp_uid: rsp.imp_uid,
            merchant_uid: rsp.merchant_uid,
            status: rsp.status, // 결제 완료 String 값
            success: rsp.success, // 결제 상태 boolean 값
            totalPrice: rsp.paid_amount,
            cartId: rsp.custom_data.cartId,
            loginId: loginId
        };
        console.log(paymentData); //paymentData를 불러옴.
        console.log("결제 응답 데이터", rsp); // !!!!!!이거 데이터 갖고 콘솔에서 찍고, 갖고와서 확인
        console.log("결제 응답 데이터", typeof rsp.success); // !!!!!!이거 데이터 갖고 콘솔에서 찍고, 갖고와서 확인
        console.log("결제 응답 데이터", typeof rsp.status); // !!!!!!이거 데이터 갖고 콘솔에서 찍고, 갖고와서 확인
        fetch(`/security-login/payment/complete?loginId=${loginId}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(paymentData) // 결제 데이터 전송
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error("서버에 결제 정보 전송 실패");
                }
                return response.json();
            })
            .then(data => {
                console.log("서버 처리 완료", data);
                alert("결제가 성공적으로 완료되었습니다!");
                // 후속 처리 (예: 결제 완료 페이지 이동 등)
            })
            .catch(error => {
                console.error("결제 후 처리 중 오류 발생:", error);
                alert("결제는 되었지만 서버 처리 중 문제가 발생했습니다.");
            });
    }

    // 결제 요청 함수
    window.requestPay = function () {
        var loginId = document.getElementById("loginId").value;

        fetchPayInfo(loginId).then(data => {
            console.log("결제 상품명:", data.menuList);
            console.log("fetchPayInfo 반환 데이터:", data);  // 실제 데이터 확인해봐!

            if (data && data.menuList.length > 0) {
                // 카트 항목들의 이름을 결제 요청 -> 메뉴 리스트를 받아온 후 하나의 문자열로 join하는데, ','기호로 단어를 separate
                var cartItem = data.menuList.map(item => `${item.menuId}`).join(",");  // menuId 사용
                var cartItemName = data.menuList.map(item => `${item.menuName} ${item.quantity}개`).join(",");  // menuName 사용
                var totalPrice = data.totalPrice;

                IMP.request_pay({
                        pg: "html5_inicis",
                        pay_method: "EASY_PAY", // 결제 수단
                        merchant_uid: `payment-${crypto.randomUUID()}`, // 상점 id값
                        buyer_name: data.userName,
                        buyer_tel: "010-8690-3944",
                        buyer_postcode: data.studentId,

                        id: cartItem, // 상품 ID
                        name: cartItemName,
                        amount: totalPrice,  // 서버에서 받은 총액 사용

                        custom_data: {
                            studentId: data.studentId,
                            menus: data.menuList,
                            reservationTime: data.reservationTime,
                            loginId: data.loginId,
                            cartId: data.cartId
                        }
                    },
                    async (response) => {
                        if (response.error_code != null) {
                            return alert(`결제에 실패하였습니다. 에러 내용: ${response.error_msg}`);
                        }

                        // 결제 성공 후 서버로 결제 완료 처리 요청
                        paySuccess(response);
                    }
                );
            }
        });
    };
});
