package com.fouridiots.capstone.dto;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.Menu;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartMenuRequest {

    private Long cartMenuId;
    private Long cartId;
    private Long menuId;

    // 장바구니 품목의 최소 수량 = 1 지정 @Min
    @Min(value = 1, message = "상품을 담아주세요")
    @Column(nullable = false)
    private int count;

}
