package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class MainController {
    private final UserService userService;

    // 시설 안내 View
    @GetMapping("/security-login/facility")
    public String facilityPage(Authentication auth, Model model) {


        if (auth != null && auth.isAuthenticated()) {
            User loginUser = userService.getLoginUserByLoginId(auth.getName());
            if (loginUser != null) {
                model.addAttribute("name", loginUser.getName()); // 사용자 로그인 불러옴
            }
        }
        return "facility"; // templates/facility.html 가져오기
    }

    @GetMapping("/security-login/event")
    public String eventPage(Authentication auth, Model model) {


        if (auth != null && auth.isAuthenticated()) {
            User loginUser = userService.getLoginUserByLoginId(auth.getName());
            if (loginUser != null) {
                model.addAttribute("name", loginUser.getName()); // 사용자 로그인 불러옴
            }
        }
        return "event"; // templates/event.html 가져오기
    }
}
