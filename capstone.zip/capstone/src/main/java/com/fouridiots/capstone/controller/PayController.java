package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.PayMenu;
import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.dto.PayInfoResponse;
import com.fouridiots.capstone.dto.PayMenuResponse;
import com.fouridiots.capstone.dto.PayRequest;
import com.fouridiots.capstone.service.PayService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/security-login/payment")
public class PayController {
    private final PayService payService;

    // PortOne에 결제정보를 넘겨주는 api
    @GetMapping("/info")
    public ResponseEntity<PayInfoResponse> getPayInfo(@RequestParam String loginId) {
        PayInfoResponse response = payService.getPayInfo(loginId);
        return ResponseEntity.ok(response);
    }

    // 결제 처리 API
    @PostMapping("/complete")
    public ResponseEntity<?> processPayment(@RequestParam String loginId, @RequestBody PayRequest payRequest) {
        try {
            payService.processPayment(loginId, payRequest);

            return ResponseEntity.ok().body(Map.of("message", "결제 성공"));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("status: " + payRequest.getStatus());
            System.out.println("success: " + payRequest.isSuccess());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "결제 실패: " + e.getMessage()));

        }
    }
}
