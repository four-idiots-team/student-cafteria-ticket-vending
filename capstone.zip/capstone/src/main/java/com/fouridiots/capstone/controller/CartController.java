package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.CartMenu;
import com.fouridiots.capstone.dto.CartRequest;
import com.fouridiots.capstone.service.CartMenuService;
import com.fouridiots.capstone.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.cglib.core.Local;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/security-login/cart")
@RequiredArgsConstructor
//REST API에서 Model을 사용하는 것보다는 JSON 응답을 반환하는 것이 더 적합하므로,
// HTML을 반환할 필요가 없다면 @RestController를 사용하고, JSON 형태로 응답을 구성
public class CartController {

    private final CartService cartService;
    private final CartMenuService cartMenuService;

    // 장바구니 금액 및 항목 조회 (REST API용, JSON 반환)
    @GetMapping("/cart")
    public ResponseEntity<?> getCart(@RequestParam String loginId) {
        try {
            int totalPrice = cartService.calculateTotalPrice(loginId);
            List<CartMenu> cartItems = cartMenuService.getCartMenus(loginId);  // ✅ 수정
            // 장바구니 항목 로그 출력
            System.out.println("Response Cart Items: " + cartItems);
            return ResponseEntity.ok(Map.of(
                    "loginId", loginId,
                    "totalPrice", totalPrice, //메뉴별 가격을 가져옴
                    "cartItems", cartItems
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("장바구니를 불러오는 데 문제가 발생했습니다.");
        }
    }

    // 총 가격 조회 -> 결제 페이지 처리 API
    @GetMapping("/total-price")
    public ResponseEntity<Integer> getTotalPrice(@RequestParam String loginId) {
        try {
            int totalPrice = cartService.calculateTotalPrice(loginId);
            return ResponseEntity.ok(totalPrice);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // 예약 시간을 설정하기 위한 API
    @PostMapping("/set-reservation-time")
    public ResponseEntity<String> setReservationTime(@RequestBody CartRequest cartRequest) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String loginId = authentication.getName(); // 로그인한 사용자의 ID
            System.out.println("Received reservationTime: " + cartRequest.getReservationTime());
            LocalDateTime reservationTime = cartRequest.getReservationTime();
           LocalDateTime closeTime = LocalTime.of(18, 50).atDate(LocalDate.now()); // 영업 끝
            LocalDateTime openTime = LocalTime.of(8, 30).atDate(LocalDate.now()); // 영업 시작
            LocalDateTime breakStart = LocalTime.of(15, 0).atDate(LocalDate.now()); // 브레이크 시작
            LocalDateTime breakEnd = LocalTime.of(18, 50).atDate(LocalDate.now()); // 브레이크 끝

            // [1]. reservationTime이 null인 경우
            if (reservationTime == null) {
                return ResponseEntity.badRequest().body("예약 시간을 선택해주세요");
            }

            /*// [2-1]. LocalTime이 영업 시간이 아닐 경우
            if (LocalDateTime.now().isBefore(openTime) || LocalDateTime.now().isAfter(closeTime)) {
                return ResponseEntity.badRequest().body("지금은 영업 시간이 아닙니다. (08:30 ~ 18:50)");
            }


            // [2-2]. reservationTime이 영업 시간이 아닐 경우
            if (openTime.isBefore(reservationTime) && closeTime.isAfter(reservationTime))
                return ResponseEntity.badRequest().body("해당 시간은 영업 시간이 아닙니다. (08:30 ~ 18:50) \n "
                        + "예약불가 (15:00 ~ 16:30)");

            //**브레이크 타임은 캡스톤 시연때 주석 처리 할 수도 있음.***
            // [3-1]. LocalTime이 브레이크 타임 일 경우
            if (LocalTime.of(15,0).isAfter(LocalTime.now()) &&
                    LocalTime.of(16,30).isBefore(LocalTime.now())) {
                return ResponseEntity.badRequest().body("지금은 브레이크 타임입니다. 예약불가 (15:00 ~ 16:30)");
            }
            // [3-2]. reservationTime이 브레이크 타임 일 경우
            if (breakStart.isAfter(reservationTime) && breakEnd.isBefore(reservationTime)) {
                return ResponseEntity.badRequest().body("해당 시각은 브레이크 타임입니다. (15:00 ~ 16:30)");
            }*/

        /*    // [4]. reservationTime이 LocalDateTime보다 이전 인 경우
            if (reservationTime.isBefore(LocalDateTime.now())) {
                return ResponseEntity.badRequest().body("유효한 예약 시간을 설정해주세요 (현재 시각보다 이전 시각)");
            }*/

            // [5]. 정상적인 예약 시간 -> 서비스 호출
            cartService.updateReservationTime(loginId, reservationTime);
            return ResponseEntity.ok("예약 시간이 설정되었습니다");

        } catch (Exception e) {
            e.printStackTrace(); // 서버 로그에 에러 출력
            // 4. 기타 예외 처리
            /*
            Request	클라이언트 → 서버로 보내는 정보	@RequestBody로 받는 예약시간 등
            Response	서버 → 클라이언트로 보내는 정보	ResponseEntity.status(400).body("메시지")
            Status Code	HTTP 상태 (성공/실패 구분)	200, 400, 500 등
            [1] 1xx: 정보 응답 (거의 안 씀)
            100 Continue, 101 Switching Protocols
            거의 쓰지 않음

            [2] 2xx: 성공 (Success)
            상태 |    코드     |	   의미        |    사용 예시
            200     OK          요청 성공	         대부분의 성공 응답
            201     Created	    리소스 생성 성공	 회원가입, 게시글 작성, 주문 생성 등
            204     No Content	응답 본문 없음	 삭제 완료 시 사용 (프론트에 굳이 응답 내용 필요 없을 때)

            [3] 3xx: 리다이렉션 (Redirect)
            301     Moved Permanently,
            302     Found                        웹페이지 리다이렉션 처리에 사용. API 작업에서는 거의 안 씀.

            [4] 4xx: 클라이언트 오류 (Client Error)

           | 상태 |           코드          |               의미                      |           사용 예시           |
            400    Bad Request	                잘못된 요청 (파라미터 오류 등)	         JSON 형식 오류, 유효하지 않은 입력
            401    Unauthorized	                인증 안됨 (로그인 안 함)	             로그인 필요한 API 요청 시
            403    Forbidden	                권한 없음	                             로그인 했지만 권한 없는 사용자
            404    Not Found	                요청한 리소스 없음	                     없는 페이지, ID, 메뉴 등
            409    Conflict	                    충돌	                                 중복 회원가입, 예약 중복 등
            422    Unprocessable Entity	        유효성 검증 실패	                     폼 입력 오류 상세하게 전달할 때

            [5] 5xx: 서버 오류 (Server Error)

            상태              코드	            의미	                사용 예시
            500     Internal Server Error	서버 내부 에러	예외 발생 시 catch 못한 상황
            502     Bad Gateway,            게이트웨이 문제
            503     Service Unavailable	    서버 다운	        외부 서비스 문제나 서버 과부하 시

            많이 쓰는 예시 상황
                상황	                    상태      코드	              설명
          로그인 안 된 사용자가 접근	        401   Unauthorized	        인증 필요
          로그인했지만 관리자만 접근 가능	    403   Forbidden	            권한 부족
          잘못된 예약 시간 형식	            400   Bad Request	        파라미터 유효성 실패
          중복된 ID로 회원가입	            409     Conflict	        중복 처리
          회원가입 성공	                201     Created	            새로운 사용자 생성
          주문 삭제 성공	                204   No Content	        응답 본문 없이 완료 처리
          서버에서 예외 발생	            500 Internal Server Error	NPE, SQL 에러 등

        java        ResponseEntity로 상태 쉽게 지정
                            java
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                     .body("예약 시간이 잘못되었습니다.");

        java
            return ResponseEntity.badRequest().body("잘못된 요청");
            return ResponseEntity.status(HttpStatus.STATUS_CODE_NAME).build();
            return ResponseEntity.ok("정상 처리 완료");
            200, 201, 204 → 성공 흐름

            400, 401, 403, 404, 409 → 프론트에게 잘못된 요청/권한 문제 알림

            500 → 서버 예외 발생 시
            */
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("예약 시간 설정에 실패했습니다.");
        }
    }


    // 즉시 조리 설정 API
    @PostMapping("/set-instant-cooking")
    public ResponseEntity<String> setInstantCooking(@RequestBody CartRequest cartRequest) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String loginId = authentication.getName(); // 로그인한 사용자 ID
            System.out.println("Received reservationTime: " + cartRequest.getReservationTime()); // 받는 값을 알기 위해서

            // 장바구니 생성 (없으면 생성됨)
            cartService.createCart(loginId);

            // 예약 시간은 현재 시간으로 업데이트
            LocalTime breakStart = LocalTime.of(15, 0); // 15:00
            LocalTime breakEnd = LocalTime.of(16, 30); // 16:30
            LocalTime now = LocalTime.now();
            // [1] 08:30 ~ 18:50 사이가 아닐 경우
            if (now.isBefore(LocalTime.of(8,30)) || now.isAfter(LocalTime.of(18,50)))
                return ResponseEntity.badRequest().body("영업 시간이 아닙니다.");

            // [2] 15:00 ~ 16:30 브레이크 타임 일 경우 -> capstone 시연 시 주석  추가
            if(now.isAfter(breakStart) && now.isBefore(breakEnd)) {
                return ResponseEntity.badRequest().body("지금은 브레이크 타임입니다.");
            }

            // [3] 정상 시간 즉시조리
            cartService.updateReservationTime(loginId, LocalDateTime.now());
            return ResponseEntity.ok("즉시 조리가 설정되었습니다");
        } 
        catch (Exception e) {
            e.printStackTrace(); // 잘못된 오류를 서버에서 확인 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("즉시 조리 설정에 실패했습니다.");
        }
    }


    // 장바구니 초기화 (페이지 새로고침)
    @DeleteMapping("/clear")
    public ResponseEntity<String> clearCart(@RequestParam String loginId) {
        cartService.clearCartForUserByUsername(loginId);
        return ResponseEntity.ok("장바구니가 초기화되었습니다.");
    }
}
