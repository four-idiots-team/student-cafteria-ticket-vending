package com.fouridiots.capstone.domain;

public enum UserRole {
        USER, ADMIN
}
