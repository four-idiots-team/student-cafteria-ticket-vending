package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "menu")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_id") //menu ID(pk)
    private Long menuId;

    @Column(name = "menu_name", nullable = false)
    private String menuName; //MENU 이름

    @Column(name = "menu_info")
    private String menuInfo; //MENU 정보

    @Column(name = "menu_price", nullable = false)
    private int menuPrice; //가격

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false) // category TABLE의 category_id를 받아옴 
    private Category category;
}
