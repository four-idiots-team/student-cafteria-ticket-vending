package com.fouridiots.capstone.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fouridiots.capstone.domain.Pay;
import jakarta.persistence.Column;
import lombok.Data;

@Data
public class PayRequest {

    @JsonProperty("imp_uid")
    private String impUid;

    @JsonProperty("merchant_uid")
    private String merchantUid;
    private Long cartId;         // 결제할 카트 ID
    private int totalPrice;      // 총 금액 (보안을 위해 서버에서 다시 검증)

    @Column(name = "status", nullable = false)
    @JsonProperty("status")
    private String status; // 결제 성공 여부 (예: true는 성공, false는 실패)

    @Column(name = "success", nullable = false)
    @JsonProperty("success")
    private boolean success;    // 결제 상태 (예: "SUCCESS", "FAILURE") -> String으로 전달

}
