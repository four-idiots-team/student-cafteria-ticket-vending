package com.fouridiots.capstone.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
    @RequestMapping("/security-login")
    @RequiredArgsConstructor
    public class CartController {

    }
