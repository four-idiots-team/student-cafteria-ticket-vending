
    function showCategory(category) {
    document.querySelectorAll('.menu-category').forEach(el => el.style.display = 'none');
    document.getElementById(category).style.display = 'block';
}
