package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.Menu;
import com.fouridiots.capstone.dto.MenuRequest;
import com.fouridiots.capstone.service.MenuService;
import com.fouridiots.capstone.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/security-login/menu")
@RequiredArgsConstructor
public class MenuController {
    private final MenuService menuService;

    // 메뉴 생성 API
    @PostMapping
    public ResponseEntity<Menu> createMenu(@RequestBody MenuRequest menuRequest) {
        Menu menu = menuService.createMenu(menuRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(menu);
    }

    // 카테고리별 메뉴 조회
    @GetMapping("/{categoryId}")
    public ResponseEntity<List<Menu>> getMenusByCategory(@PathVariable Long categoryId) {
        List<Menu> menus = menuService.getMenusByCategory(categoryId);
        return menus.isEmpty() ? ResponseEntity.notFound().build() : ResponseEntity.ok(menus);
    }
}
