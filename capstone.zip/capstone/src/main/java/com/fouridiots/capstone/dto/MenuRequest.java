package com.fouridiots.capstone.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
public class MenuRequest {

    private Long categoryId;
    private String menuName;
    private String menuInfo;
    private int menuPrice;

    @Builder
    public MenuRequest(Long categoryId, String menuName, String menuInfo, int menuPrice) {
        this.categoryId = categoryId;
        this.menuName = menuName;
        this.menuInfo = menuInfo;
        this.menuPrice = menuPrice;
    }
}
