package com.fouridiots.capstone.repository;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

    // 유저의 장바구니 조회
    Cart findByUser(User user);
    // 유저의 장바구니 삭제 (초기화용)
    void deleteByUser(User user);
}
