package com.fouridiots.capstone.repository;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.CartMenu;
import com.fouridiots.capstone.domain.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartMenuRepository extends JpaRepository<CartMenu, Long> {
    List<CartMenu> findByCart(Cart cart);
    CartMenu findByCartAndMenu(Cart cart, Menu menu); // 중복 확인용
}
