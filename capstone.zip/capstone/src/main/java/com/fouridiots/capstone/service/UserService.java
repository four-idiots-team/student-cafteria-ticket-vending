package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.dto.JoinRequest;
import com.fouridiots.capstone.dto.LoginRequest;
import com.fouridiots.capstone.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    public boolean checkLoginIdDuplicate(String loginId){

        return userRepository.existsByLoginId(loginId);
    }
    public void join(JoinRequest joinRequest) {
        userRepository.save(joinRequest.toEntity());
    }

    public void securityJoin(JoinRequest joinRequest){
        if(userRepository.existsByLoginId(joinRequest.getLoginId())){
            return;
        }

        joinRequest.setPassword(bCryptPasswordEncoder.encode(joinRequest.getPassword()));
        userRepository.save(joinRequest.toEntity());
    }

    public User getLoginUserByLoginId(String loginId) {
        return userRepository.findByLoginId(loginId);

    }

    public User login(LoginRequest loginRequest) {
        User findUser = userRepository.findByLoginId(loginRequest.getLoginId());

        if(findUser == null){
            return null;
        }

        if (!findUser.getPassword().equals(loginRequest.getPassword())) {
            return null;
        }

        return findUser;
    }

    public User getLoginUserById(Long userId){
        if(userId == null) return null;

        Optional<User> findUser = userRepository.findById(userId);
        return findUser.orElse(null);

    }
    public User getLoginMemberByLoginId(String loginId){
        if(loginId == null) return null;

        return userRepository.findByLoginId(loginId);

    }

}
