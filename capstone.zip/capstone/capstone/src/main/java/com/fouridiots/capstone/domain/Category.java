package com.fouridiots.capstone.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;
// 3계층 구조 -> 2계층으로 표현
/* 3Layer
parentCategory1
    |---------> childCategory1
    |                |----------> Menu1
parentCategory2
    |---------> childCategory2
    |                |----------> Menu2
parentCategory3
    |---------> childCategory3
                     |----------> Menu3
                     
               ...
*/

/* 2Layer
category1
    |----------> 메뉴1
category2
    |----------> 메뉴2
category3
    |----------> 메뉴3

        ...
 */
@Builder(toBuilder = true)
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "category")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private Long categoryId; // 카테고리 아이디 PK

    @Column(name = "category_name", nullable = false)
    private String categoryName; // 카테고리 이름

    @Column(nullable = false, unique = true)
    private String depth; // CODE로 바꿔야함.
    
    // LAZY는 필요할때만 사용 <-> EAGER 항상 호출
    @ManyToOne(fetch = FetchType.LAZY) // N:1 관계
    @JoinColumn(name = "parent_id") // 부모 id category table이 부모 column 이므로 NULL값
    private Category parent;

    @OneToMany(mappedBy = "parent") // 1:N 관계
    @JsonIgnore // 부모와 자식간의 참조 무한순환을 막기위해 사용
    private List<Category> children;

    // 생성자에서만 parent 설정 가능
    public Category(Long categoryId, String categoryName, String depth, Category parent) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.depth = depth;
        this.parent = parent;
    }

}