package com.fouridiots.capstone.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuRequest {

    private Long menuId; // 메뉴 아이디

    private String menu_price; // 메뉴 가격
    private String menu_name; // 메뉴 이름
}
