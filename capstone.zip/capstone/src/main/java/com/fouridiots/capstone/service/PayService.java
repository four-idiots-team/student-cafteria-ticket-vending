package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.Pay;
import com.fouridiots.capstone.domain.PayMenu;
import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.dto.PayInfoResponse;
import com.fouridiots.capstone.dto.PayMenuResponse;
import com.fouridiots.capstone.dto.PayRequest;
import com.fouridiots.capstone.repository.CartRepository;
import com.fouridiots.capstone.repository.PayMenuRepository;
import com.fouridiots.capstone.repository.PayRepository;
import com.fouridiots.capstone.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PayService {

    private final UserRepository userRepository;
    private final CartRepository cartRepository;
    private final CartService cartService;
    private final PayRepository payRepository;
    private final PayMenuRepository payMenuRepository;

    // 결제 정보 조회
    public PayInfoResponse getPayInfo(String loginId) {
        User user = userRepository.findByLoginId(loginId);
        if (user == null) {
            throw new RuntimeException("유저가 존재하지 않습니다.");
        }

        Cart cart = cartRepository.findByUser(user);
        if (cart == null) {
            throw new RuntimeException("장바구니가 없습니다.");
        }

        List<PayInfoResponse.MenuInfo> menuList = cart.getCartMenus().stream()
                .map(cm -> new PayInfoResponse.MenuInfo(
                        cm.getMenu().getMenuId(),
                        cm.getMenu().getMenuName(),
                        cm.getMenu().getMenuPrice(),
                        cm.getCount()
                ))
                .toList();

        return new PayInfoResponse(
                loginId,
                user.getStudentId(),
                user.getName(),
                cart.getCartId(),
                menuList,
                cartService.calculateTotalPrice(loginId),
                cart.getReservationTime() != null ? cart.getReservationTime().toString() : null
        );
    }

    // 결제 정보 처리
    @Transactional
    public void processPayment(String loginId, PayRequest payRequest) {
        // 1. 유저 조회 및 예외 처리
        User user = userRepository.findByLoginId(loginId);
        if (user == null) {
            throw new RuntimeException("유저가 존재하지 않습니다.");
        }

        // 2. 장바구니 조회 및 예외 처리
        Cart cart = cartService.getCartByLoginIdAndCartId(user.getLoginId(), payRequest.getCartId());
        if (cart == null) {
            throw new RuntimeException("장바구니가 존재하지 않습니다.");
        }

        // 3. 총 가격 계산
        int totalPrice = cartService.calculateTotalPrice(user.getLoginId());

        // 4. 결제 정보 저장
        Pay pay = new Pay(cart, totalPrice, payRequest.getStatus(), payRequest.isSuccess()); // 생성자 호출
        payRepository.save(pay);

        // 5. 결제된 메뉴(PayMenu) 저장
        List<PayMenu> payMenus = cart.getCartMenus().stream()
                .map(cartMenu -> new PayMenu(pay, cartMenu.getMenu(), cartMenu.getCount())) // PayMenu 객체 생성
                .collect(Collectors.toList());

        // PayMenu 저장
        payMenuRepository.saveAll(payMenus);
    }


    // 결제된 메뉴를 DTO로 반환
    // 로그인한 유저의 cart인지 확인 후 DTO 반환
    public List<PayMenuResponse> getPayMenusByCategory(Long cartId, String loginId) {
        // 로그인한 유저 조회
        User user = userRepository.findByLoginId(loginId);
        if (user == null) {
            throw new RuntimeException("유저가 존재하지 않습니다.");
        }

        // cartId로 결제 정보 조회
        Pay pay = payRepository.findByCartCartId(cartId)
                .orElseThrow(() -> new IllegalArgumentException("결제 정보가 존재하지 않습니다."));

        // 유저 소유 cart인지 확인
        if (!pay.getCart().getUser().getLoginId().equals(loginId)) {
            throw new SecurityException("접근 권한이 없습니다.");
        }

        // PayMenu -> DTO 변환
        return payMenuRepository.findByPayCartCartId(cartId).stream()
                .map(payMenu -> new PayMenuResponse(
                        payMenu.getPayMenuId(),
                        payMenu.getMenu().getMenuName(),
                        payMenu.getCount(),
                        payMenu.getMenu().getMenuPrice(),
                        payMenu.getMenu().getCategory().getCategoryName()))
                .collect(Collectors.toList());
    }
}
