
// 라디오 버튼을 변경할 때마다 실행되는 함수
function toggleTimeInput() {
    const timeOption = document.querySelector('input[name="timeOption"]:checked').value;
    const reservationTimeInput = document.getElementById('reservationTime');

    if (timeOption === 'reservation') {
        reservationTimeInput.disabled = false; // 예약 시간이 선택되면 시간 입력 활성화
    } else {
        reservationTimeInput.disabled = true;  // 즉시 조리 선택 시 시간 입력 비활성화
    }
}

// 예약 시간 설정 서버 전달 함수
function submitReservationTime() {
    const timeOption = document.querySelector('input[name="timeOption"]:checked');
    let reservationTime = null;

    if (timeOption && timeOption.value === 'reservation') { // timeOption이 null인 경우 방지
        const timeValue = document.getElementById('reservationTime').value; // "HH:mm"
        if (timeValue) {  // 시간이 입력되지 않으면 처리
            const today = new Date().toISOString().split('T')[0]; // "YYY-MM-DDT" 반환
            reservationTime = `${today} ${timeValue}:00`; // "2025-04-17 12:30"
        } else {
            alert('예약 시간을 선택하세요.'); // 예약 시간이 입력되지 않으면 알림
            return;
        }
        /*
                함수	                            설명
        new Date().toISOString()	        ISO 8601 문자열
        new Date().toLocaleString('sv-SE')	YYYY-MM-DD HH:mm:ss 형식 (스웨덴 포맷)

        new Date().getTime()	            밀리초 단위의 Timestamp
        const yyyy = now.getFullYear();
        const mm = String(now.getMonth() + 1).padStart(2, '0');
        const dd = String(now.getDate()).padStart(2, '0');
        const hh = String(now.getHours()).padStart(2, '0');
        const min = String(now.getMinutes()).padStart(2, '0'); // mm은 2자리로 보통 나타내므로, YYYY-MM-DD HH:01 과 같이 1분 단위가 들어오면 2자리로 나타내야함
        const ss = String(now.getSeconds()).padStart(2, '0');
        */
    }


    $.ajax({
        url: '/security-login/cart/set-reservation-time',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            reservationTime: reservationTime
        }),
        success: function(response) {
            alert('예약 시간이 설정되었습니다.');
        },
        error: function(xhr, status, error) {
            alert(xhr.responseText);
            /*
            1. xhr (XMLHttpRequest 객체)
               - 실제 요청과 응답의 모든 정보를 담는 객체
                 응답 코드, 응답 본문, 헤더 보기

                    javascript
                console.log(xhr.status);         // HTTP 상태 코드 (예: 404, 500)
                console.log(xhr.responseText);   // 서버에서 온 에러 메시지
                console.log(xhr.getAllResponseHeaders()); // 응답 헤더 전체
            2. status
                - Ajax 요청 자체의 상태를 나타내는 문자열
                예: "timeout", "error", "abort", "parsererror"

                    javascript
                console.log(status);  // "error", "timeout", 등등
            3. error
                - 서버가 반환한 에러 메시지 또는 예외 정보
                - 대부분은 설명적인 문자열이거나, 브라우저가 생성한 메시지

                    javascript
                console.log(error);  // 예: "Internal Server Error"


                    javascript
                error: function(xhr, status, error) {
                    console.log("상태코드: " + xhr.status);
                    console.log("응답내용: " + xhr.responseText);
                    console.log("상태: " + status);
                    console.log("에러메시지: " + error);

                    alert("에러 발생: " + xhr.responseText);
                }
            }
            */
        }
    });

}

// 즉시 조리 선택 시 처리
function submitInstantCooking() {
    const timeOption = document.querySelector('input[name="timeOption"]:checked').value;
    let reservationTime = null;

    if (timeOption === 'reservation') {
        const timeValue = document.getElementById('reservationTime').value; // "HH:mm"
        const sec = date.getSeconds().padStart(2, '0');
        const today = new Date().toISOString().split('T')[0]; // "yyyy-MM-dd"
        reservationTime = '${today} ${timeValue}:${sec}'; // "YYYY-MM-DD HH:mm:ss"
    }
    console.log("예약 시간:", reservationTime); // "2025-04-17 15:26:30"
    // 즉시 조리 API 호출 (AJAX)
    $.ajax({
        url: '/security-login/cart/set-instant-cooking', // API 엔드포인트
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            reservationTime: reservationTime // 예약 시간이 선택되었으면 그 값을 사용, 없으면 null
        }),
        success: function(response) {
            alert('즉시 조리가 설정되었습니다.');
        },
        error: function(xhr, status, error) {
            alert(xhr.responseText); // ← 백엔드에서 보낸 메시지를 그대로 띄움
        }
    });
}

// 라디오 버튼 클릭 시 이벤트 리스너 추가
document.querySelectorAll('input[name="timeOption"]').forEach(radio => {
    radio.addEventListener('change', toggleTimeInput);
});

// "결제하기" 버튼 클릭 시 예약 시간 또는 즉시 조리 설정 보내기
document.querySelector('button').addEventListener('click', function() {
    const timeOption = document.querySelector('input[name="timeOption"]:checked').value;
    if (timeOption === 'reservation') {
        submitReservationTime();
    } else {
        submitInstantCooking();
    }
});

// 카테고리별 메뉴 불러오기
function fetchMenusByCategory(button) {
    let categoryId = button.getAttribute("data-category-id");

    const imageMap = {
        "일반라면": "https://placehold.co/100x100?text=라면",
        "계란라면": "https://placehold.co/100x100?text=계란",
        "치즈라면": "https://placehold.co/100x100?text=치즈",
        "만두라면": "https://placehold.co/100x100?text=만두",
        "떡라면": "https://placehold.co/100x100?text=떡",
        "공기밥": "https://placehold.co/100x100?text=밥",
        "해장라면": "https://placehold.co/100x100?text=해장",
        "치즈떡라면": "https://placehold.co/100x100?text=치즈떡",
        "추가": "https://placehold.co/100x100?text=추가"
    };

    $.ajax({
        url: "/security-login/menu/" + categoryId,
        method: "GET",
        success: function(menus) {
            const menuList = $("#menuList");
            menuList.empty();

            if (menus.length === 0) {
                menuList.append("<p>메뉴가 없습니다.</p>");
                return;
            }

            menus.forEach(menu => {
                let imageUrl = "https://placehold.co/100x100?text=메뉴";

                for (let keyword in imageMap) {
                    if (menu.menuName.includes(keyword)) {
                        imageUrl = imageMap[keyword];
                        break;
                    }
                }

                const card = `
                    <div class="menu-card" data-menu-id="${menu.menuId}" data-count="1">
                        <img src="${imageUrl}" alt="${menu.menuName}">
                        <div class="name">${menu.menuName}</div>
                        <div class="info">${menu.menuInfo}</div>
                        <div class="price">${menu.menuPrice.toLocaleString()}원</div>

                        <div class="quantity-control">
                            <button onclick="decreaseCount(this)">-</button>
                            <span class="count">1</span>
                            <button onclick="increaseCount(this)">+</button>
                        </div>

                        <button onclick="addToCart(this)">장바구니 추가</button>
                    </div>
                `;

                menuList.append(card);
            });

            openMenuModal();
        },
        error: function(xhr) {
            alert(xhr.status === 404
                ? "해당 카테고리에 메뉴가 없습니다."
                : "서버 오류 발생! 관리자에게 문의하세요.");
        }
    });
}

// 수량 증가
function increaseCount(button) {
    let menuCard = $(button).closest(".menu-card");
    let count = parseInt(menuCard.attr("data-count"));
    count++;
    menuCard.attr("data-count", count);
    menuCard.find(".count").text(count);
}

// 수량 감소
function decreaseCount(button) {
    let menuCard = $(button).closest(".menu-card");
    let count = parseInt(menuCard.attr("data-count"));
    if (count > 1) {
        count--;
        menuCard.attr("data-count", count);
        menuCard.find(".count").text(count);
    }
}

function addToCart(button) {
    const menuCard = $(button).closest(".menu-card");
    const menuId = menuCard.attr("data-menu-id");
    const count = parseInt(menuCard.attr("data-count"));
    const loginId = $("#loginId").val();

    const existingMenu = $("#addedMenuList .added-card").filter(function() {
        return $(this).data("menu-id") == menuId;
    });

    // 수량 계산
    let finalCount = count;

    if (existingMenu.length > 0) {
        let existingCount = parseInt(existingMenu.find(".count").text());
        finalCount += existingCount;
    }

    // PUT 방식으로 업데이트 요청
    const url = existingMenu.length > 0 ? "/security-login/cart/update/" + menuId  : "/security-login/cart/add";

    $.ajax({
        url: url,
        method: existingMenu.length > 0 ? "PUT" : "POST", // PUT 요청으로 변경
        data: {
            loginId: loginId,
            menuId: menuId,
            count: finalCount
        },
        success: function() {
            // UI 업데이트
            if (existingMenu.length > 0) {
                existingMenu.find(".count").text(finalCount);
                updateItemPrice(menuId);
            } else {
                const menuName = menuCard.find(".name").text();
                const priceText = menuCard.find(".price").text();
                const unitPrice = parseInt(priceText.replace(/[^\d]/g, ""));

                const card = `
                    <div class="added-card" data-menu-id="${menuId}" data-price="${unitPrice}">
                        <strong>${menuName}</strong>
                        <p>수량: <span class="count">${finalCount}</span></p>
                        <p>가격: <span class="price">${(unitPrice * finalCount).toLocaleString()}원</span></p>
                    </div>
                `;
                $("#addedMenuList").append(card);
            }

            // 총 가격 요청
            fetchTotalPrice();
        },
        error: function() {
            alert("장바구니 처리 중 오류가 발생했습니다.");
        }
    });
}

// 메뉴 수량별 가격 자동 업데이트
function updateItemPrice(menuId) {
    const card = $(`.added-card[data-menu-id="${menuId}"]`);
    const count = parseInt(card.find(".count").text());
    const unitPrice = parseInt(card.attr("data-price"));
    const newPrice = unitPrice * count;

    card.find(".price").text(newPrice.toLocaleString() + "원");
}

// 장바구니 총 가격
function fetchTotalPrice() {
    const loginId = $("#loginId").val();

    $.get(`/security-login/cart/total-price?loginId=${loginId}`, function(totalPrice) {
        if (totalPrice !== null) {
            $("#totalPrice").text(totalPrice.toLocaleString() + "원");
            // .toLocaleString(): 1000인 int형 숫자 -> 1,000인 문자열 형식으로 변환
            $("#cartTotal").show(); // 총 가격 영역 보이게
        } else {
            alert("총 가격을 불러오는 데 실패했습니다.");
        }
    });
}

// pop-up 열기
function openMenuModal() {
    $("#menuModal").removeClass("hidden");
}

// pop-up 닫기
function closeMenuModal() {
    $("#menuModal").addClass("hidden");
}

// 페이지 새로고침 시 처리
function initializeCart() {
    const loginId = $("#loginId").val();

    $.get(`/security-login/cart/items?loginId=${loginId}`, function(cartItems) {
        const addedSection = $("#addedMenuList");
        addedSection.empty(); // 기존 요소 제거

        cartItems.forEach(item => {
            const menuId = item.menu.menuId;
            const menuName = item.menu.menuName;
            const count = item.count;
            const unitPrice = item.menu.menuPrice;

            const card = `
                <div class="added-card" data-menu-id="${menuId}" data-price="${unitPrice}">
                    <strong>${menuName}</strong>
                    <p>수량: <span class="count">${count}</span></p>
                    <p>가격: <span class="price">${(unitPrice * count).toLocaleString()}원</span></p>
                </div>
            `;
            addedSection.append(card);
        });

        fetchTotalPrice(); // 총 가격도 함께 표시
    });
}

$(document).ready(function() {
    initializeCart(); // 페이지 로딩 시 장바구니 정보 불러오기
});
