package com.fouridiots.capstone.repository;

import com.fouridiots.capstone.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    // 특정 부모 ID에 속하는 자식 카테고리만 가져오기 (손자 X)
    List<Category> findByParentCategoryId(Long parentId);
}
