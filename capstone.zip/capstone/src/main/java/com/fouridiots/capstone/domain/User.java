package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;


@Entity
@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_id")
    private Long userId;

    @Column(name = "student_id")
    private String studentId;

    private String loginId;
    private String password;
    private String name;

    @CreationTimestamp
    private LocalDateTime createTimestamp; //생성 일

    @UpdateTimestamp
    private LocalDateTime updateTimestamp; //수정 일

    @Enumerated(EnumType.STRING)
    private UserRole role;

}