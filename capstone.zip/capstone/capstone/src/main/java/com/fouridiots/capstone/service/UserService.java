package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.dto.JoinRequest;
import com.fouridiots.capstone.dto.LoginRequest;
import com.fouridiots.capstone.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    // join시 아이디 중복 체크 method
    public boolean checkLoginIdDuplicate(String loginId){

        return userRepository.existsByLoginId(loginId);
    }

    // join 정보를 저장하는 method
    public void join(JoinRequest joinRequest) {

        userRepository.save(joinRequest.toEntity());
    }

    //
    public void securityJoin(JoinRequest joinRequest){
        if(userRepository.existsByLoginId(joinRequest.getLoginId())){
            return;
        }

        joinRequest.setPassword(bCryptPasswordEncoder.encode(joinRequest.getPassword()));
        userRepository.save(joinRequest.toEntity());
    }

    // 로그인 시 사용자 정보 조회
    public User getLoginUserByLoginId(String loginId) {
        return userRepository.findByLoginId(loginId);

    }
    //사용자가 입력한 로그인 정보(loginId, password)를 이용해 로그인 검증을 수행.
    //userRepository.findByLoginId(loginRequest.getLoginId())를 통해 사용자 조회.
    //입력한 비밀번호와 저장된 비밀번호가 일치하는지 비교.
    public User login(LoginRequest loginRequest) {
        User findUser = userRepository.findByLoginId(loginRequest.getLoginId());

        if(findUser == null){
            return null;
        }

        if (!bCryptPasswordEncoder.matches(loginRequest.getPassword(), findUser.getPassword())) {
            return null;
        }


        return findUser;
    }

    public User getLoginUserById(Long userId){
        if(userId == null) return null;

        Optional<User> findUser = userRepository.findById(userId);
        return findUser.orElse(null);

    }

}
