package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Getter
@NoArgsConstructor
@AllArgsConstructor

@Builder
/*
(Builder Pattern)의 장점
- 필요한 데이터만 설정
- 유연성 확보
- 가독성 up
- 변경 가능성을 최소화
*/

@Table(name = "menu")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_id") //menu ID(pk)
    private Long menuId;

    @Column(name = "menu_name", nullable = false)
    private String menuName; //MENU 이름

    @Column(name = "menu_info")
    private String menuInfo; //MENU 정보

    @Column(name = "menu_price", nullable = false)
    private int menuPrice; //가격

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false) // category TABLE의 category_id를 받아옴 
    private Category category;
}
