package com.fouridiots.capstone.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fouridiots.capstone.domain.Menu;
import com.fouridiots.capstone.domain.User;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Getter
public class CartRequest {

    // JSON 포맷을 "yyyy-MM-dd HH:mm:ss"로 지정
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime reservationTime;  // 예약 시간 추가


    @Builder
    public CartRequest(LocalDateTime reservationTime) {

        this.reservationTime = reservationTime;
    }

}
