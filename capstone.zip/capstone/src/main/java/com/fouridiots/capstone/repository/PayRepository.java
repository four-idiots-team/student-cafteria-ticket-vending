package com.fouridiots.capstone.repository;

import com.fouridiots.capstone.domain.Pay;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayRepository extends JpaRepository<Pay, Long> {

    // cartId로 결제 정보를 찾기 -> 단일 결제 정보
    Optional<Pay> findByCartCartId(Long cartId);


    // 결제 날짜 기준으로 결제 내역 정렬 -> 이전 결제 정보 보여줄거임
    List<Pay> findAllByCart_User_UserIdOrderByPayDateDesc(Long userId);
}
