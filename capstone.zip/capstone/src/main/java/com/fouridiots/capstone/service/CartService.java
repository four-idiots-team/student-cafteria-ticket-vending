package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.repository.CartRepository;
import com.fouridiots.capstone.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalTime;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final UserRepository userRepository;

    // 유저의 장바구니 생성 -> user의 loginId로 생성 / 메뉴가 담기는 순간 카트 생성
// 장바구니 전체 시간 설정 (전체 시간 동일)
    // 장바구니 생성 (예약 시간 없이)
    public Cart createCart(String loginId) {
        User user = userRepository.findByLoginId(loginId);
        if (user == null) throw new RuntimeException("유저 없음");

        Cart cart = cartRepository.findByUser(user);

        if (cart == null) {
            cart = new Cart(user, null);  // 예약 시간은 나중에 설정
            cartRepository.save(cart);
        }

        return cart;
    }
    @Transactional(readOnly = true)
    public Cart getCartByLoginIdAndCartId(String loginId, Long cartId) {
        User user = userRepository.findByLoginId(loginId);
        if (user == null) {
            throw new RuntimeException("유저가 존재하지 않습니다.");
        }

        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("장바구니가 존재하지 않습니다."));

        if (!cart.getUser().equals(user)) {
            throw new RuntimeException("해당 유저의 장바구니가 아닙니다.");
        }

        return cart;
    }

    // 예약 시간만 따로 설정
    @Transactional
    public void updateReservationTime(String loginId, LocalDateTime reservationTime) {
        User user = userRepository.findByLoginId(loginId);
        if (user == null) throw new RuntimeException("유저 없음");

        Cart cart = cartRepository.findByUser(user);
        if (cart == null) throw new RuntimeException("장바구니 없음");

        cart.setReservationTime(reservationTime);
        cartRepository.save(cart);
    }

    // 장바구니 총 가격 계산
    @Transactional
    public int calculateTotalPrice(String loginId) {
        User user = userRepository.findByLoginId(loginId);
        Cart cart = cartRepository.findByUser(user);

        if (cart == null) {
            return 0; // 장바구니가 없으면 0원
        }

        return cart.getCartMenus().stream()
                .mapToInt(cm -> cm.getMenu().getMenuPrice() * cm.getCount())
                .sum();
    }


    // 장바구니 초기화 (새로고침 시 사용)
    @Transactional
    public void clearCartForUserByUsername(String loginId) {
        User user = userRepository.findByLoginId(loginId);
        if (user != null) {
            cartRepository.deleteByUser(user);
        }
    }
}
