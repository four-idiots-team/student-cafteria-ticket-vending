package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.Category;
import com.fouridiots.capstone.dto.CategoryRequest;
import com.fouridiots.capstone.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Category createCategory(CategoryRequest categoryRequest) {
        Category category = Category.builder()
                .categoryName(categoryRequest.getCategoryName())
                .depth(categoryRequest.getDepth())
                .build();

        // 부모 카테고리가 있으면 설정
        if (categoryRequest.getParentId() != null) {
            Category parentCategory = categoryRepository.findById(categoryRequest.getParentId())
                    .orElseThrow(() -> new RuntimeException("부모 카테고리를 찾을 수 없습니다."));
            category = category.toBuilder()
                    .parent(parentCategory)
                    .build();
        }

        return categoryRepository.save(category);
    }

    // 부모 카테고리 ID로 자식 카테고리들 조회
    public List<Category> getCategoryByParentId(Long parentId) {
        return categoryRepository.findByParentCategoryId(parentId);  // Long 타입을 사용하여 자식 카테고리 조회
    }
    // 모든 카테고리 조회
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

}
