package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.Cart;
import com.fouridiots.capstone.domain.CartMenu;
import com.fouridiots.capstone.domain.Menu;
import com.fouridiots.capstone.repository.CartMenuRepository;
import com.fouridiots.capstone.repository.MenuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CartMenuService {
    private final CartService cartService;
    private final CartMenuRepository cartMenuRepository;
    private final MenuRepository menuRepository;

    // 장바구니 메뉴 조회
    public List<CartMenu> getCartMenus(String loginId) {
        Cart cart = cartService.createCart(loginId);
        return cartMenuRepository.findByCart(cart);
    }

    // 장바구니에 메뉴 추가
    @Transactional
    public void addMenuToCart(String loginId, Long menuId, int count) {
        Cart cart = cartService.createCart(loginId);  // 로그인 ID로 카트 생성
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("메뉴 없음"));

        CartMenu existing = cartMenuRepository.findByCartAndMenu(cart, menu);

        if (existing != null) {
            existing.addCount(count);
            cartMenuRepository.save(existing);
        } else {
            CartMenu newCartMenu = new CartMenu(cart, menu, count);
            cart.getCartMenus().add(newCartMenu);
            cartMenuRepository.save(newCartMenu);
        }

        cartService.calculateTotalPrice(loginId);
    }

    // 수량 변경 (0이면 삭제)
    @Transactional
    public void updateCartMenuCount(String loginId, Long menuId, int count) {
        Cart cart = cartService.createCart(loginId);
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("메뉴 없음"));

        CartMenu cartMenu = cartMenuRepository.findByCartAndMenu(cart, menu);
        if (cartMenu != null) {
            if (count == 0) {
                cartMenuRepository.delete(cartMenu); // 수량 0이면 삭제
            } else {
                cartMenu.changeCount(count);
                cartMenuRepository.save(cartMenu);
            }
        } else {
            throw new RuntimeException("해당 메뉴가 장바구니에 없습니다.");
        }
    }

    // 장바구니 항목 삭제
    @Transactional
    public void removeCartMenu(String loginId, Long cartMenuId) {
        Cart cart = cartService.createCart(loginId);
        CartMenu cartMenu = cartMenuRepository.findById(cartMenuId)
                .orElseThrow(() -> new IllegalArgumentException("해당 항목이 존재하지 않습니다."));

        if (!cart.getCartMenus().contains(cartMenu)) {
            throw new IllegalArgumentException("해당 항목이 장바구니에 없습니다.");
        }

        cartMenuRepository.deleteById(cartMenuId);
    }
}
