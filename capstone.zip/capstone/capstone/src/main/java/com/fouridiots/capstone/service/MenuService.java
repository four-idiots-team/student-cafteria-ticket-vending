package com.fouridiots.capstone.service;

import com.fouridiots.capstone.domain.Category;
import com.fouridiots.capstone.domain.Menu;
import com.fouridiots.capstone.dto.MenuRequest;
import com.fouridiots.capstone.repository.CategoryRepository;
import com.fouridiots.capstone.repository.MenuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MenuService {

    private final MenuRepository menuRepository;
    private final CategoryRepository categoryRepository;

    public List<Menu> getMenusByCategory(Long categoryId) {
        Optional<Category> category = categoryRepository.findById(categoryId);
        if (category.isEmpty()) {
            return Collections.emptyList();
        }

        Category selectedCategory = category.get();

        // 손자(3계층) 카테고리는 제외하고 메뉴만 조회
        if (selectedCategory.getChildren().isEmpty()) {
            return menuRepository.findByCategory_CategoryId(categoryId);
        } else {
            return Collections.emptyList();
        }
    }

    public Menu createMenu(MenuRequest menuRequest) {
        Category category = categoryRepository.findById(menuRequest.getCategoryId())
                .orElseThrow(() -> new IllegalArgumentException("카테고리 없음"));

        Menu menu = Menu.builder()
                .menuName(menuRequest.getMenuName())
                .menuInfo(menuRequest.getMenuInfo())
                .menuPrice(menuRequest.getMenuPrice())
                .category(category)
                .build();

        return menuRepository.save(menu);
    }
}
