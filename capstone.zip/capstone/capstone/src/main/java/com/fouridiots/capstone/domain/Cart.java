package com.fouridiots.capstone.domain;

import jakarta.persistence.*;
import lombok.Getter;

@Entity
@Table(name="cart")
@Getter
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cart_id", nullable = false) // 장바구니
    private Long cartId;

    @Column(name="quantity", nullable = false) // 수량
    private int quantity;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="id", nullable=false) // User 테이블의 PK -> FK(Foreign Key)
    private User user;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="menu_id", nullable=false) // Menu 테이블의 PK -> Forein Key
    private Menu menu;
}
