package com.fouridiots.capstone.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class PayMenuResponse {
    private Long payMenuId;
    private String menuName;  // 메뉴 이름
    private int count;        // 수량
    private int price;        // 가격
    private String category;  // 카테고리 이름 (메뉴 카테고리)
}
