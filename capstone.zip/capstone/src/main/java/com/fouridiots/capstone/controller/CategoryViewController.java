package com.fouridiots.capstone.controller;

import com.fouridiots.capstone.domain.Category;
import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.service.CategoryService;
import com.fouridiots.capstone.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/security-login")
@RequiredArgsConstructor
public class CategoryViewController {
    private final UserService userService;
    private final CategoryService categoryService;

    // 카테고리 목록 조회 -> /security-login/menu
    @GetMapping("/menu")
    public String viewCategories(Authentication auth, Model model) {
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("loginType", "security-login");
        model.addAttribute("pageName", "세명학식");

        if (auth != null && auth.isAuthenticated()) {
            User loginUser = userService.getLoginUserByLoginId(auth.getName());
            if (loginUser != null) {
                model.addAttribute("name", loginUser.getName()); // name을 불러옴
            }
        }

        return "menu";  // 👉 Thymeleaf 템플릿 (resources/templates/menu.html)
    }
}
