function fetchMenus() {
    let categoryId = document.getElementById("categorySelect").value;
    if (categoryId === "-1") {
        alert("카테고리를 선택하세요!");
        return;
    }

    const imageMap = {
        "일반라면": "https://placehold.co/100x100?text=라면",
        "계란라면": "https://placehold.co/100x100?text=계란",
        "치즈라면": "https://placehold.co/100x100?text=치즈",
        "만두라면": "https://placehold.co/100x100?text=만두",
        "떡라면": "https://placehold.co/100x100?text=떡",
        "공기밥": "https://placehold.co/100x100?text=밥",
        "해장라면": "https://placehold.co/100x100?text=해장",
        "치즈떡라면": "https://placehold.co/100x100?text=치즈떡",
        "추가": "https://placehold.co/100x100?text=추가"
    };

    $.ajax({
        url: "/security-login/menu/" + categoryId,
        method: "GET",
        success: function(menus) {
            const menuList = $("#menuList");
            menuList.empty();  // 기존 메뉴 초기화

            if (menus.length === 0) {
                menuList.append("<p>메뉴가 없습니다.</p>");
                return;
            }

            // 메뉴 카드들을 직접 menuList에 append
            menus.forEach(menu => {
                let imageUrl = "https://placehold.co/100x100?text=메뉴";
                for (let keyword in imageMap) {
                    if (menu.menuName.includes(keyword)) {
                        imageUrl = imageMap[keyword];
                        break;
                    }
                }

                const card = `
                    <div class="menu-card">
                        <img src="${imageUrl}" alt="${menu.menuName}">
                        <div class="name">${menu.menuName}</div>
                        <div class="info">${menu.menuInfo}</div>
                        <div class="price">${menu.menuPrice.toLocaleString()}원</div>
                    </div>
                `;
                menuList.append(card); // ✅ 바로 menuList에 추가
            });
        },
        error: function(xhr) {
            if (xhr.status === 404) {
                alert("해당 카테고리에 메뉴가 없습니다.");
            } else {
                alert("서버 오류 발생! 관리자에게 문의하세요.");
            }
        }
    });
}
