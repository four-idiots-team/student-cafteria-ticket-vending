package com.fouridiots.capstone.dto;

import com.fouridiots.capstone.domain.User;
import com.fouridiots.capstone.domain.UserRole;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class JoinRequest {
    @NotBlank(message="학번을 입력하세요")
    private String studentId;

    @NotBlank(message = "ID를 입력하세요.")
    private String loginId;

    @NotBlank(message = "비밀번호를 입력하세요.")
    private String password;
    private String passwordCheck;

    @NotBlank(message = "이름을 입력하세요.")
    private String name;

    public User toEntity() {
        return User.builder()
                .studentId(this.studentId)
                .loginId(this.loginId)
                .password(this.password)
                .name(this.name)
                .role(UserRole.USER)
                .build();
    }
}
