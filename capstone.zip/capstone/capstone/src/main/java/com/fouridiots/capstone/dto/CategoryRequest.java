package com.fouridiots.capstone.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryRequest {

        private String categoryName; // 카테고리 이름
        private String depth; // 카테고리 코드
        private Long parentId; // 부모 카테고리 ID

}
